<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php'
require 'phpmailer/src/PHPMailer.php'
require 'phpmailer/src/SMTP.php'

if(isset($_POST["send"])){
    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth=true;
    $mail->Username='dayanochka63@gmail.com';
    $mail->Password = 'gelf xmmy mbpi fevz';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('dayanochka63@gmail.com');

    $mail->addAddress($_POST["email"]);
    $mail->isHTML(true);

    $mail->Subject = $_POST["subject"];
    $mail->Body = $_POST["message"];
    $mail->send();

}





// $to = "daana4511@gmail.com"; 
//     $name = clear_data($_POST['name']);
//     $surname = clear_data($_POST['surname']);
// 	$phone = clear_data($_POST['phone']);
//     $email = clear_data($_POST['email']);
//     $text = clear_data($_POST['text']);

// 	$date = date ("d.m.Y"); 
// 	$time = date ("h:i");
// 	$from = "daana4511@gmail.com"; 
// 	$subject = "Заявка c сайта";
// function clear_data($val){
//     $val =trim($val);
//     $val =stripcslashes($val);
//     $val =htmlspecialchars($val);
//     return $val;
// }
	
// 	$msg="
//     Имя: $name /n
//     Фамилия: $surname /n
//     Телефон: $phone /n
//     Почта: $email /n
//     Текст: $text"; 	
//     if(isset($_POST['button'])){
//         mail($to, $subject, $msg, "From: $from ");
//     }
	

?>

<p>Привет, форма отправлена</p>
